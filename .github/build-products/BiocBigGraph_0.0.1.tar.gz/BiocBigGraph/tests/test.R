library(BiocBigGraph)
library(testthat)

test_check("BiocBigGraph")

