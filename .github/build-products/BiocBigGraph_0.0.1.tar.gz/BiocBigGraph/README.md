# BiocBigGraph
interface to facebook research PyTorch-BigGraph, inspired by pinellolab SIMBA
